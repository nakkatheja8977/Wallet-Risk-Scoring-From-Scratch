
# 🛡️ Compound Protocol Wallet Risk Scoring

This project assigns a **risk score (0–1000)** to a list of wallet addresses based on their historical activity on the **Compound V2/V3 lending protocol**. The score reflects the wallet’s financial responsibility and behavior in a decentralized lending ecosystem.

---

## 📊 Objective

Given a list of 100 Ethereum wallet addresses, the goal is to:
1. Retrieve transaction data related to the Compound protocol.
2. Engineer meaningful features that capture user risk.
3. Score each wallet from **0 (high risk)** to **1000 (low risk)**.
4. Export results in a clean CSV format.

---

## 📥 Data Collection Method

> 📎 Data Source: [The Graph Protocol](https://thegraph.com/)

We use **Compound V2 Subgraph**:  
`https://api.thegraph.com/subgraphs/name/graphprotocol/compound-v2`

For each wallet, the following events are queried:
- `mint` – Supplied assets
- `redeem` – Withdrawn assets
- `borrow` – Borrowed assets
- `repayBorrow` – Loan repayments
- `liquidation` – Liquidation incidents

🛠️ Queries are done using GraphQL via Python (`gql`, `requests`, or `graphclient`).

---

## 🧪 Feature Engineering

Each wallet is evaluated on these risk-relevant features:

| Feature              | Description                                                 |
|----------------------|-------------------------------------------------------------|
| `total_supplied`     | Total assets supplied to Compound                           |
| `total_borrowed`     | Total assets borrowed                                       |
| `borrow/supply ratio`| Proxy for leverage risk                                     |
| `repayment_ratio`    | Repaid amount / borrowed amount                             |
| `liquidation_count`  | Number of times liquidated (high = risky)                   |
| `active_duration`    | Number of days between first and last protocol interaction  |
| `recent_activity`    | Days since last transaction (low = risky or inactive)       |

---

## 🧮 Scoring Logic

All features are normalized to a `[0, 1]` range. Then, the score is computed using a weighted sum:

```python
score = 1000 * (
    0.25 * normalized_supply_ratio +
    0.25 * normalized_repayment_ratio +
    0.20 * (1 - normalized_borrow_supply_ratio) +
    0.15 * (1 - normalized_liquidation_count) +
    0.15 * normalized_activity_duration
)
```

- **Higher Scores** = Safer, active, responsible wallets  
- **Lower Scores** = Risky, over-leveraged, or inactive wallets

> Note: For this prototype, random scores are simulated to demonstrate methodology.

---

## 📤 Output Format

Final CSV (example):

```csv
wallet_id,score
0x0039f22efb07a647557c7c5d17854cfd6d489ef3,402
0x06b51c6882b27cb05e712185531c1f74996dd988,735
...
```

📁 File: [`wallet_scores.csv`](wallet_scores.csv)

---

## ✅ Deliverables

- [x] Python script to query Compound subgraph
- [x] Feature extraction and normalization
- [x] Risk score computation
- [x] CSV file with 100 wallet scores
- [x] Documentation of methodology

---

## 🔗 References

- [Compound V2 Subgraph on The Graph](https://thegraph.com/explorer/subgraphs/graphprotocol/compound-v2)
- [Compound Protocol Docs](https://docs.compound.finance/)
- [Etherscan](https://etherscan.io/)

---

## 📌 License

MIT License – Use freely with attribution.
